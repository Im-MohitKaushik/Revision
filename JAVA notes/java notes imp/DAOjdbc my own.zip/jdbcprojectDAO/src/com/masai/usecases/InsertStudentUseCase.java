package com.masai.usecases;

import java.util.Scanner;

import com.masai.dao.StudentDao;
import com.masai.dao.StudentDaoImpl;

public class InsertStudentUseCase {

	
	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter name");
		String name=sc.next();
		System.out.println("enter marks");
		int  marks =sc.nextInt();
		
		
		StudentDao dao=new StudentDaoImpl();
		String result=dao.insertStudentDetails(name, marks);
		System.out.println(result);
	}
}
