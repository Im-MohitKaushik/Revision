package com.masai.usecases;

import java.sql.Connection;

import com.masai.utility.DButil;

public class ConnectionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn=DButil.provideConnection();
		
	}

}
