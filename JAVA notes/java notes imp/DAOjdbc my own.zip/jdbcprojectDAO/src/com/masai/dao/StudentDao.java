package com.masai.dao;

public interface StudentDao {
	
	public String insertStudentDetails(String name,int marks);
}
