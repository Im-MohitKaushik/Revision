package com.masai.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.masai.utility.DButil;

public class StudentDaoImpl implements StudentDao {

	@Override
	public String insertStudentDetails(String name, int marks) {
			String message="not inserted....";
			
			try (Connection conn=DButil.provideConnection()){
				
			PreparedStatement ps =conn.prepareStatement("insert into student values(?,?)");
				
			ps.setString(1,name);
			ps.setInt(2, marks);
			int x=ps.executeUpdate();
			if(x>0) {
				message="record inserted";
				
			}
			
			
			} catch (SQLException e) {
				// TODO: handle exception
				message=e.getMessage();
			}
			
			
			return message;
	}

	
	
}
